<?php

namespace Database\Factories;

use App\Models\RevisionTicket;
use App\Models\TicketComment;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/** @extends Factory<TicketComment> */
class TicketCommentFactory extends Factory
{
    protected $model = TicketComment::class;

    public function definition(): array
    {
        return [
            'ticket_id' => RevisionTicket::factory(),
            'user_id' => User::factory(),
            'body' => fake()->sentence(),
        ];
    }
}
