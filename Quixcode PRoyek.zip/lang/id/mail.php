<?php

return [
    'greeting' => 'Halo :name,',
    'salutation' => 'Salam, Tim Quix Code',

    'lead_welcome' => [
        'subject' => 'Permintaan proyek ":project" telah kami terima',
        'intro' => 'Terima kasih telah mengajukan brief proyek ":project" ke Quix Code. Tim kami segera meninjau kebutuhan Anda.',
        'setup_hint' => 'Kami telah menyiapkan akun Client Portal untuk memantau penawaran, progres, dan tagihan Anda. Atur kata sandi akun Anda melalui tautan aman berikut:',
        'action' => 'Atur Kata Sandi Portal',
        'outro' => 'Tautan ini bersifat pribadi dan memiliki batas waktu berlaku demi keamanan akun Anda.',
    ],

    'quotation_sent' => [
        'subject' => 'Penawaran baru v:version untuk :project',
        'intro' => 'Kami telah mengirim penawaran versi :version untuk proyek ":project".',
        'total' => 'Total penawaran: :total',
        'valid_until' => 'Penawaran berlaku sampai :date.',
        'no_limit' => 'Penawaran ini tidak memiliki batas waktu.',
        'action' => 'Lihat penawaran',
        'outro' => 'Di portal Anda bisa menyetujui, menolak, atau bernegosiasi lewat chat.',
    ],

    'quotation_expiring' => [
        'subject' => 'Penawaran v:version untuk :project segera berakhir',
        'intro' => 'Penawaran versi :version untuk proyek ":project" berlaku sampai :date (:when).',
        'days' => '{0} berakhir hari ini|{1} tinggal 1 hari|[2,*] tinggal :count hari',
        'action' => 'Lihat penawaran',
        'outro' => 'Jika masih perlu waktu atau perubahan, tulis di chat sebelum penawaran berakhir.',
    ],

    'dp_invoice' => [
        'subject' => 'Invoice DP :number untuk :project',
        'intro' => 'Terima kasih telah menyetujui penawaran proyek ":project". Invoice DP sudah terbit.',
        'number' => 'Nomor invoice: :number',
        'amount' => 'Jumlah: :amount',
        'due' => 'Jatuh tempo: :date',
        'no_due' => 'Tanpa tanggal jatuh tempo.',
        'action' => 'Lihat invoice',
        'outro' => 'Pengerjaan dimulai setelah pembayaran DP kami verifikasi.',
    ],

    'chat_digest' => [
        'subject_admin' => 'Pesan baru dari klien di :project',
        'subject_client' => 'Pesan baru dari tim Quix Code di :project',
        'intro' => '{1} Ada 1 pesan baru yang belum dibaca di proyek ":project".|[2,*] Ada :count pesan baru yang belum dibaca di proyek ":project".',
        'hint' => 'Isi pesan tidak disertakan di email ini. Buka chat untuk membacanya.',
        'action' => 'Buka chat',
    ],

    'invoice_issued' => [
        'subject' => 'Invoice :number untuk :project',
        'intro' => 'Invoice baru untuk proyek ":project" sudah terbit.',
        'number' => 'Nomor invoice: :number',
        'amount' => 'Jumlah: :amount',
        'due' => 'Jatuh tempo: :date',
        'no_due' => 'Tanpa tanggal jatuh tempo.',
        'action' => 'Lihat tagihan',
        'outro' => 'Setelah membayar, unggah bukti pembayaran di halaman tagihan.',
    ],

    'invoice_reminder' => [
        'subject_due_soon' => 'Invoice :number untuk :project segera jatuh tempo',
        'subject_due_today' => 'Invoice :number untuk :project jatuh tempo hari ini',
        'subject_overdue' => 'Invoice :number untuk :project sudah lewat jatuh tempo',
        'intro_due_soon' => 'Invoice untuk proyek ":project" akan jatuh tempo dalam :days hari.',
        'intro_due_today' => 'Invoice untuk proyek ":project" jatuh tempo hari ini.',
        'intro_overdue' => 'Invoice untuk proyek ":project" sudah lewat jatuh tempo.',
        'number' => 'Nomor invoice: :number',
        'amount' => 'Sisa tagihan: :amount',
        'due' => 'Jatuh tempo: :date',
        'action' => 'Lihat tagihan',
        'outro' => 'Jika sudah membayar, unggah bukti pembayaran di halaman tagihan. Abaikan email ini jika bukti sudah Anda kirim.',
    ],

    'ticket_sla' => [
        'subject' => '[Quix Code] :count tiket belum dibalas lebih dari :hours jam',
        'intro' => ':count tiket belum mendapat balasan tim lebih dari :hours jam:',
        'item' => '- :title (:project)',
        'more' => 'Dan :count tiket lainnya.',
        'action' => 'Buka papan tiket',
        'outro' => 'Tiket yang sama hanya dilaporkan satu kali.',
    ],

    'payment_verified' => [
        'subject' => 'Pembayaran invoice :number diterima',
        'intro' => 'Bukti pembayaran Anda untuk invoice :number (proyek ":project") sudah kami verifikasi.',
        'amount' => 'Pembayaran diterima: :amount',
        'remaining' => 'Sisa tagihan: :amount',
        'paid_off' => 'Invoice ini sudah lunas.',
        'action' => 'Lihat tagihan',
        'outro' => 'Terima kasih atas pembayarannya.',
    ],

    'payment_rejected' => [
        'subject' => 'Bukti pembayaran invoice :number perlu diperbaiki',
        'intro' => 'Bukti pembayaran Anda untuk invoice :number (proyek ":project") belum dapat kami terima.',
        'amount' => 'Jumlah yang Anda kirim: :amount',
        'reason' => 'Alasan: :reason',
        'action' => 'Unggah bukti baru',
        'outro' => 'Anda dapat mengunggah ulang bukti pembayaran yang benar di halaman tagihan.',
    ],

    'ticket_replied' => [
        'subject' => 'Balasan baru untuk permintaan ":ticket"',
        'intro' => 'Tim kami membalas permintaan ":ticket" di proyek ":project".',
        'hint' => 'Isi balasan tidak disertakan di email ini. Buka portal untuk membacanya.',
        'action' => 'Buka portal',
    ],

    'ops_alert' => [
        'subject_failed_job' => '[Quix Code] Job gagal permanen',
        'subject_queue_busy' => '[Quix Code] Antrean menumpuk',
        'subject_stale_webhook' => '[Quix Code] Tidak ada aktivitas webhook GitHub 24 jam',
        'subject_stale_exchange_rate' => '[Quix Code] Kurs mata uang publik usang > 48 jam',
        'stale_webhook_intro' => 'Proyek aktif ":project" (:repo) tidak menerima pengiriman webhook GitHub yang valid selama lebih dari :hours jam.',
        'stale_exchange_rate_intro' => 'Kurs estimasi publik IDR/USD belum diperbarui selama lebih dari :hours jam atau belum tersedia di basis data.',
        'failed_job_intro' => 'Job :job di antrean ":queue" gagal permanen dan masuk tabel failed_jobs.',
        'error' => 'Galat: :error',
        'queue_busy_intro' => 'Antrean ":queue" (koneksi :connection) menumpuk: :size job menunggu.',
        'outro' => 'Periksa worker (Supervisor) dan tabel failed_jobs. Peringatan serupa dibatasi satu kali per beberapa menit.',
    ],
];
