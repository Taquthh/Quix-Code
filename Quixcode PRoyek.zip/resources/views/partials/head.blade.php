<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>
    {{ filled($title ?? null) ? __($title).' - '.config('app.name', 'Laravel') : config('app.name', 'Laravel') }}
</title>

<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

@vite(['resources/css/app.css', 'resources/js/app.js'])
{{-- Tema bawaan per area (admin gelap, portal terang). Pilihan pengguna di Settings > Appearance tetap dihormati. --}}
<script>
    try {
        if (! localStorage.getItem('flux.appearance')) {
            localStorage.setItem('flux.appearance', @js($appearance ?? 'dark'));
        }
    } catch (e) {}
</script>
@fluxAppearance
