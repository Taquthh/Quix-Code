<?php # [BlazeVersion]:{v3} ?>
<?php if (isset($component)) { $__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::public','data' => ['locale' => $locale,'seo' => $seo]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['locale' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($locale),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <section class="border-b border-slate-200 bg-white">
        <div class="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:py-16">
            <div class="max-w-3xl space-y-3">
                <h1 class="font-heading text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
                    <?php echo e(__('public.works.title')); ?>

                </h1>
                <p class="text-base leading-relaxed text-slate-600 sm:text-lg">
                    <?php echo e(__('public.works.subtitle')); ?>

                </p>
            </div>
        </div>
    </section>

    <section class="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:py-16">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($works->isEmpty()): ?>
            <div class="rounded-2xl border border-slate-200 bg-white p-10 text-center">
                <h2 class="font-heading text-lg font-semibold text-slate-900"><?php echo e(__('public.works.empty_title')); ?></h2>
                <p class="mt-2 text-sm text-slate-600"><?php echo e(__('public.works.empty_description')); ?></p>
            </div>
        <?php else: ?>
            <div class="grid gap-6 md:grid-cols-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <article class="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-xs transition hover:border-emerald-300">
                        <div class="space-y-3">
                            <h2 class="font-heading text-lg font-semibold text-slate-900">
                                <a href="<?php echo e(route('public.works.show', ['locale' => $locale, 'slug' => $work->slug])); ?>" class="hover:text-emerald-700">
                                    <?php echo e($work->localized('title', $locale)); ?>

                                </a>
                            </h2>
                            <p class="text-sm leading-relaxed text-slate-600">
                                <?php echo e($work->localized('summary', $locale)); ?>

                            </p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_array($work->tech_stack) && $work->tech_stack !== []): ?>
                                <div class="flex flex-wrap gap-1.5 pt-1">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $work->tech_stack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <span class="rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-xs font-medium text-slate-700">
                                            <?php echo e($tech); ?>

                                        </span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="pt-6">
                            <a href="<?php echo e(route('public.works.show', ['locale' => $locale, 'slug' => $work->slug])); ?>"
                               class="inline-flex items-center text-sm font-semibold text-emerald-700 hover:text-emerald-800">
                                <?php echo e(__('public.works.read_case')); ?> &rarr;
                            </a>
                        </div>
                    </article>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <div class="mt-10">
                <?php echo e($works->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3)): ?>
<?php $attributes = $__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3; ?>
<?php unset($__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3)): ?>
<?php $component = $__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3; ?>
<?php unset($__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3); ?>
<?php endif; ?>
<?php /**PATH /home/qnf/Quix-Code/resources/views/public/works.blade.php ENDPATH**/ ?>