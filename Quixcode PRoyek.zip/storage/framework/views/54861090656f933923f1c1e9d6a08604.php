<?php # [BlazeVersion]:{v3} ?>
<?php if (isset($component)) { $__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::public','data' => ['locale' => $locale,'seo' => $seo]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['locale' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($locale),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <section class="border-b border-slate-200 bg-white">
        <div class="mx-auto max-w-5xl px-4 py-14 sm:px-6 lg:py-16">
            <div class="max-w-3xl space-y-3">
                <h1 class="font-heading text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
                    <?php echo e(__('public.about.title')); ?>

                </h1>
                <p class="text-base leading-relaxed text-slate-600 sm:text-lg">
                    <?php echo e(__('public.about.subtitle')); ?>

                </p>
            </div>
        </div>
    </section>

    <section class="mx-auto max-w-5xl space-y-12 px-4 py-14 sm:px-6 lg:py-16">
        <div class="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs sm:p-8">
            <h2 class="font-heading text-2xl font-bold text-slate-900">
                <?php echo e(__('public.about.story_title')); ?>

            </h2>
            <p class="mt-3 text-base leading-relaxed text-slate-700">
                <?php echo e(__('public.about.story_body')); ?>

            </p>
        </div>

        <div class="grid gap-6 md:grid-cols-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['transparency', 'engineering', 'security']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
                    <h3 class="font-heading text-lg font-semibold text-slate-900">
                        <?php echo e(__('public.about.values.'.$val.'.title')); ?>

                    </h3>
                    <p class="mt-2 text-sm leading-relaxed text-slate-600">
                        <?php echo e(__('public.about.values.'.$val.'.body')); ?>

                    </p>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <?php ($team = (array) config('quix.team', [])); ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($team !== []): ?>
            <div>
                <div class="max-w-2xl space-y-2">
                    <h2 class="font-heading text-2xl font-bold text-slate-900"><?php echo e(__('public.about.team_title')); ?></h2>
                    <p class="text-base text-slate-600"><?php echo e(__('public.about.team_subtitle')); ?></p>
                </div>
                <div class="mt-6 grid gap-6 md:grid-cols-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
                            <h3 class="font-heading text-lg font-semibold text-slate-900"><?php echo e($member['name'] ?? ''); ?></h3>
                            <p class="mt-0.5 text-xs font-semibold uppercase tracking-wide text-emerald-700">
                                <?php echo e(is_array($member['role'] ?? null) ? ($member['role'][$locale] ?? $member['role']['id'] ?? '') : ($member['role'] ?? '')); ?>

                            </p>
                            <p class="mt-3 text-sm leading-relaxed text-slate-600">
                                <?php echo e(is_array($member['bio'] ?? null) ? ($member['bio'][$locale] ?? $member['bio']['id'] ?? '') : ($member['bio'] ?? '')); ?>

                            </p>
                        </article>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3)): ?>
<?php $attributes = $__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3; ?>
<?php unset($__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3)): ?>
<?php $component = $__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3; ?>
<?php unset($__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3); ?>
<?php endif; ?>
<?php /**PATH /home/qnf/Quix-Code/resources/views/public/about.blade.php ENDPATH**/ ?>