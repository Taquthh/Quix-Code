<?php # [BlazeVersion]:{v3} ?>
<?php
    // Bahasa dari segmen URL (/en/...), karena middleware web tidak berjalan pada sebagian halaman error.
    $segment = request()->segment(1);
    $locale = in_array($segment, ['id', 'en'], true) ? $segment : (in_array(app()->getLocale(), ['id', 'en'], true) ? app()->getLocale() : 'id');
    app()->setLocale($locale);
?>
<?php if (isset($component)) { $__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::public','data' => ['locale' => $locale,'simple' => true,'seo' => ['title' => '404 — Quix Code']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['locale' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($locale),'simple' => true,'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['title' => '404 — Quix Code'])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <section class="mx-auto max-w-2xl px-4 py-24 text-center sm:px-6">
        <p class="font-heading text-sm font-bold uppercase tracking-widest text-emerald-600">404</p>
        <h1 class="mt-3 font-heading text-3xl font-bold text-slate-900"><?php echo e(__('public.errors.404.title')); ?></h1>
        <p class="mt-3 text-sm leading-relaxed text-slate-600"><?php echo e(__('public.errors.404.body')); ?></p>
        <a href="<?php echo e(route('public.home', ['locale' => $locale])); ?>" class="mt-6 inline-flex min-h-11 items-center rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white">
            <?php echo e(__('public.errors.back_home')); ?>

        </a>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3)): ?>
<?php $attributes = $__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3; ?>
<?php unset($__attributesOriginala3ffd7b6f4ed8b1b5263d00782f431a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3)): ?>
<?php $component = $__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3; ?>
<?php unset($__componentOriginala3ffd7b6f4ed8b1b5263d00782f431a3); ?>
<?php endif; ?>
<?php /**PATH /home/qnf/Quix-Code/resources/views/errors/404.blade.php ENDPATH**/ ?>