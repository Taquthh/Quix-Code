<?php # [BlazeVersion]:{v3} ?>
<?php # [BlazeFolded]:{flux::button}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/button/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::button}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/button/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::button}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/button/index.blade.php}:{1795048155} ?>
<div class="flex flex-col gap-6">
    <div class="flex flex-wrap items-start justify-between gap-3">
        <div>
            <h1 class="font-heading text-2xl font-bold text-slate-900 dark:text-slate-50"><?php echo e(__('admin.settings.title')); ?></h1>
            <p class="text-sm text-slate-600 dark:text-slate-400"><?php echo e(__('admin.settings.subtitle')); ?></p>
        </div>
        <div class="flex flex-wrap gap-2">
            <?php ob_start(); ?><a href="<?php echo e(route('admin.settings.templates')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-white hover:bg-zinc-50 dark:bg-zinc-700 dark:hover:bg-zinc-600/75 text-zinc-800 dark:text-white border border-zinc-200 hover:border-zinc-200 disabled:border-zinc-200 border-b-zinc-300/80 dark:border-zinc-600 dark:hover:border-zinc-600 dark:disabled:border-zinc-600 shadow-xs [[data-flux-button-group]_&amp;]:border-s-0 [:is([data-flux-button-group]&gt;&amp;:first-child,_[data-flux-button-group]_:first-child&gt;&amp;)]:border-s-[1px]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <?php ob_start(); ?><?php echo e(__('admin.templates.title')); ?><?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><a href="<?php echo e(route('admin.team.index')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-white hover:bg-zinc-50 dark:bg-zinc-700 dark:hover:bg-zinc-600/75 text-zinc-800 dark:text-white border border-zinc-200 hover:border-zinc-200 disabled:border-zinc-200 border-b-zinc-300/80 dark:border-zinc-600 dark:hover:border-zinc-600 dark:disabled:border-zinc-600 shadow-xs [[data-flux-button-group]_&amp;]:border-s-0 [:is([data-flux-button-group]&gt;&amp;:first-child,_[data-flux-button-group]_:first-child&gt;&amp;)]:border-s-[1px]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <?php ob_start(); ?><?php echo e(__('admin.settings.back_to_team')); ?><?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
        </div>
    </div>

    <form wire:submit="save" class="flex flex-col gap-6">
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.settings.company')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.settings.company'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <div class="grid gap-4 md:grid-cols-2">
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'companyName','label' => __('admin.settings.company_name'),'autocomplete' => 'organization']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'companyName', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'autocomplete' => 'organization'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'companyNpwp','label' => __('admin.settings.npwp')]; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'companyNpwp', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label'])], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_a1b156ddfea0f8b6864e9c3dbd3bc029')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/textarea.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'companyAddress','label' => __('admin.settings.company_address'),'rows' => '3','class' => 'md:col-span-2']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _a1b156ddfea0f8b6864e9c3dbd3bc029($__blaze, $__componentData, ['wire:model' => 'companyAddress', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'rows' => '3', 'class' => 'md:col-span-2'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.settings.bank')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.settings.bank'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <div class="grid gap-4 md:grid-cols-3">
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'bankName','label' => __('admin.settings.bank_name')]; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'bankName', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label'])], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'bankAccountName','label' => __('admin.settings.account_name')]; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'bankAccountName', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label'])], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'bankAccountNumber','label' => __('admin.settings.account_number'),'inputmode' => 'numeric','autocomplete' => 'off']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'bankAccountNumber', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'inputmode' => 'numeric', 'autocomplete' => 'off'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.settings.defaults')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.settings.defaults'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <div class="grid gap-4 md:grid-cols-3">
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'taxRatePercent','type' => 'number','min' => '0','max' => '100','step' => '0.01','label' => __('admin.settings.tax_rate')]; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'taxRatePercent', 'type' => 'number', 'min' => '0', 'max' => '100', 'step' => '0.01', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label'])], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'defaultRateIdr','type' => 'number','min' => '0','step' => '1','label' => __('admin.settings.default_rate_idr')]; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'defaultRateIdr', 'type' => 'number', 'min' => '0', 'step' => '1', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label'])], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'defaultRateUsd','type' => 'number','min' => '0','step' => '0.01','label' => __('admin.settings.default_rate_usd')]; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model' => 'defaultRateUsd', 'type' => 'number', 'min' => '0', 'step' => '0.01', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label'])], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_da6feeb405af189fc0eced19dbef8790')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/error.blade.php'); } ?>
<?php $__componentData = ['name' => 'taxRatePercent']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _da6feeb405af189fc0eced19dbef8790($__blaze, $__componentData, ['name' => 'taxRatePercent'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_da6feeb405af189fc0eced19dbef8790')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/error.blade.php'); } ?>
<?php $__componentData = ['name' => 'defaultRateIdr']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _da6feeb405af189fc0eced19dbef8790($__blaze, $__componentData, ['name' => 'defaultRateIdr'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_da6feeb405af189fc0eced19dbef8790')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/error.blade.php'); } ?>
<?php $__componentData = ['name' => 'defaultRateUsd']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _da6feeb405af189fc0eced19dbef8790($__blaze, $__componentData, ['name' => 'defaultRateUsd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.settings.templates')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.settings.templates'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <div class="grid gap-5 xl:grid-cols-2">
                <?php if (!function_exists('_a1b156ddfea0f8b6864e9c3dbd3bc029')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/textarea.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'invoiceFooterId','label' => __('admin.settings.invoice_footer_id'),'rows' => '4']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _a1b156ddfea0f8b6864e9c3dbd3bc029($__blaze, $__componentData, ['wire:model' => 'invoiceFooterId', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'rows' => '4'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_a1b156ddfea0f8b6864e9c3dbd3bc029')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/textarea.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'invoiceFooterEn','label' => __('admin.settings.invoice_footer_en'),'rows' => '4']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _a1b156ddfea0f8b6864e9c3dbd3bc029($__blaze, $__componentData, ['wire:model' => 'invoiceFooterEn', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'rows' => '4'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_a1b156ddfea0f8b6864e9c3dbd3bc029')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/textarea.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'termsTemplateId','label' => __('admin.settings.terms_id'),'rows' => '6']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _a1b156ddfea0f8b6864e9c3dbd3bc029($__blaze, $__componentData, ['wire:model' => 'termsTemplateId', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'rows' => '6'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_a1b156ddfea0f8b6864e9c3dbd3bc029')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/textarea.blade.php'); } ?>
<?php $__componentData = ['wire:model' => 'termsTemplateEn','label' => __('admin.settings.terms_en'),'rows' => '6']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _a1b156ddfea0f8b6864e9c3dbd3bc029($__blaze, $__componentData, ['wire:model' => 'termsTemplateEn', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'rows' => '6'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

        <div class="flex justify-end">
            <?php ob_start(); ?><button type="submit" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[1px]! [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)] *:transition-opacity [&amp;[disabled]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[disabled]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[disabled]]:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:loading.attr="disabled">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?><?php echo e(__('admin.settings.save')); ?><?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
        </div>
    </form>
</div>
<?php /**PATH /home/qnf/Quix-Code/resources/views/livewire/admin/settings/index.blade.php ENDPATH**/ ?>