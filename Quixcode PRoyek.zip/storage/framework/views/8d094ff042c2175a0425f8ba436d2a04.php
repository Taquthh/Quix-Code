<?php # [BlazeVersion]:{v3} ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'locale' => app()->getLocale(),
    'seo' => [],
    'simple' => false,
    'captcha' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'locale' => app()->getLocale(),
    'seo' => [],
    'simple' => false,
    'captcha' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $activeLocale = in_array($locale, ['id', 'en'], true) ? $locale : 'id';
    $title = $seo['title'] ?? 'Quix Code — Integrated Software Agency & Client Portal';
    $description = $seo['description'] ?? __('public.seo.home_description');
    $canonical = $seo['canonical'] ?? url()->current();
    $alternates = $seo['alternates'] ?? [
        'id' => url('/id'),
        'en' => url('/en'),
        'x-default' => url('/id'),
    ];
    $ogLocale = $seo['og_locale'] ?? ($activeLocale === 'en' ? 'en_US' : 'id_ID');
    // Halaman error (simple) tidak menyentuh sesi/DB agar tetap tampil saat sistem bermasalah.
    $selectedCurrency = $simple ? \App\Enums\Currency::IDR : \App\Support\PublicCurrencyEstimator::selectedCurrency();
    $ogImage = $seo['image'] ?? url('/og-default.png');
    $captchaSiteKey = $captcha && config('services.captcha.driver') === 'turnstile' && filled(config('services.captcha.secret_key'))
        ? (string) config('services.captcha.site_key')
        : '';
    $analyticsProvider = (string) config('services.analytics.provider', 'none');
    $analyticsDomain = (string) config('services.analytics.domain', '');
    $analyticsScript = (string) config('services.analytics.script_url', '');
?>
<!DOCTYPE html>
<html lang="<?php echo e($activeLocale); ?>">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($title); ?></title>
    <meta name="description" content="<?php echo e($description); ?>" />
    <link rel="canonical" href="<?php echo e($canonical); ?>" />

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $alternates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hreflang => $href): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <link rel="alternate" hreflang="<?php echo e($hreflang); ?>" href="<?php echo e($href); ?>" />
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="Quix Code" />
    <meta property="og:title" content="<?php echo e($title); ?>" />
    <meta property="og:description" content="<?php echo e($description); ?>" />
    <meta property="og:url" content="<?php echo e($canonical); ?>" />
    <meta property="og:locale" content="<?php echo e($ogLocale); ?>" />
    <meta property="og:image" content="<?php echo e($ogImage); ?>" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta name="twitter:image" content="<?php echo e($ogImage); ?>" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?php echo e($title); ?>" />
    <meta name="twitter:description" content="<?php echo e($description); ?>" />

    <link rel="icon" href="/favicon.ico" sizes="any">
    <link rel="icon" href="/favicon.svg" type="image/svg+xml">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">

    <link rel="preconnect" href="https://fonts.bunny.net" crossorigin>
    <link rel="preload" as="style" href="https://fonts.bunny.net/css?family=outfit:600,700|plus-jakarta-sans:400,500,600,700&display=swap" />
    <link href="https://fonts.bunny.net/css?family=outfit:600,700|plus-jakarta-sans:400,500,600,700&display=swap" rel="stylesheet" />

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($captchaSiteKey !== ''): ?>
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit" async defer></script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($analyticsProvider === 'plausible' && $analyticsDomain !== '' && $analyticsScript !== ''): ?>
        <script defer data-domain="<?php echo e($analyticsDomain); ?>" src="<?php echo e($analyticsScript); ?>"></script>
    <?php elseif($analyticsProvider === 'umami' && $analyticsDomain !== '' && $analyticsScript !== ''): ?>
        <script defer data-website-id="<?php echo e($analyticsDomain); ?>" src="<?php echo e($analyticsScript); ?>"></script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <script type="application/ld+json">
        <?php echo json_encode([
            '<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>' => 'https://schema.org',
            '@graph' => [
                [
                    '@type' => 'ProfessionalService',
                    '@id' => url('/').'#organization',
                    'name' => 'Quix Code',
                    'url' => url('/'.$activeLocale),
                    'logo' => url('/apple-touch-icon.png'),
                    'image' => $ogImage,
                    'description' => $description,
                    'availableLanguage' => ['Indonesian', 'English'],
                    'areaServed' => 'Global',
                ],
                [
                    '@type' => 'WebSite',
                    '@id' => url('/').'#website',
                    'name' => 'Quix Code',
                    'url' => url('/'.$activeLocale),
                    'inLanguage' => $activeLocale,
                    'publisher' => ['@id' => url('/').'#organization'],
                ],
                [
                    '@type' => 'WebPage',
                    'url' => $canonical,
                    'name' => $title,
                    'description' => $description,
                    'inLanguage' => $activeLocale,
                    'isPartOf' => ['@id' => url('/').'#website'],
                ],
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>

    </script>
</head>
<body class="min-h-screen bg-slate-50 text-slate-900 antialiased selection:bg-emerald-600 selection:text-white" x-data="{ mobileMenu: false }">
    <header class="sticky top-0 z-40 border-b border-slate-800/80 bg-slate-950/95 text-slate-100 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
            <a href="<?php echo e(route('public.home', ['locale' => $activeLocale])); ?>" class="flex items-center gap-2.5 font-heading text-lg font-bold tracking-tight text-white">
                <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-600 text-sm font-bold text-white">QC</span>
                <span>Quix Code</span>
            </a>

            <nav aria-label="<?php echo e(__('public.nav.aria')); ?>" class="hidden items-center gap-6 text-sm font-medium text-slate-300 md:flex">
                <a href="<?php echo e(route('public.services', ['locale' => $activeLocale])); ?>" class="transition hover:text-white"><?php echo e(__('public.nav.services')); ?></a>
                <a href="<?php echo e(route('public.works', ['locale' => $activeLocale])); ?>" class="transition hover:text-white"><?php echo e(__('public.nav.works')); ?></a>
                <a href="<?php echo e(route('public.about', ['locale' => $activeLocale])); ?>" class="transition hover:text-white"><?php echo e(__('public.nav.about')); ?></a>
                <a href="<?php echo e(route('public.faq', ['locale' => $activeLocale])); ?>" class="transition hover:text-white"><?php echo e(__('public.nav.faq')); ?></a>
            </nav>

            <div class="hidden items-center gap-2.5 md:flex">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($simple)): ?>
                
                <div class="inline-flex rounded-lg border border-slate-800 bg-slate-900 p-0.5 text-xs">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['IDR', 'USD']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <form method="POST" action="<?php echo e(route('public.currency', $curr)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="min-h-8 rounded-md px-2.5 py-1 font-medium transition <?php echo e($selectedCurrency->value === $curr ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'); ?>">
                                <?php echo e($curr); ?>

                            </button>
                        </form>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                
                <div class="inline-flex rounded-lg border border-slate-800 bg-slate-900 p-0.5 text-xs">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['id' => 'ID', 'en' => 'EN']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <form method="POST" action="<?php echo e(route('locale.update', $code)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="min-h-8 rounded-md px-2.5 py-1 font-medium transition <?php echo e($activeLocale === $code ? 'bg-slate-700 text-white' : 'text-slate-300 hover:text-white'); ?>">
                                <?php echo e($label); ?>

                            </button>
                        </form>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="inline-flex min-h-11 items-center rounded-lg border border-slate-700 px-3.5 py-2 text-sm font-medium text-slate-200 transition hover:border-slate-500 hover:text-white">
                        <?php echo e(__('public.nav.dashboard')); ?>

                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="inline-flex min-h-11 items-center rounded-lg px-3 py-2 text-sm font-medium text-slate-300 transition hover:text-white">
                        <?php echo e(__('public.nav.login')); ?>

                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <a href="<?php echo e(route('public.start-project', ['locale' => $activeLocale])); ?>" class="inline-flex min-h-11 items-center rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-500">
                    <?php echo e(__('public.nav.start_project')); ?>

                </a>
            </div>

            <button type="button" @click="mobileMenu = !mobileMenu" :aria-expanded="mobileMenu" aria-controls="public-mobile-menu" class="inline-flex min-h-11 min-w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-slate-200 transition hover:bg-white/[0.08] md:hidden" aria-label="<?php echo e(__('public.nav.aria')); ?>">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
        </div>

        <div id="public-mobile-menu" x-show="mobileMenu" x-cloak class="border-t border-white/10 bg-slate-950 px-4 py-4 md:hidden">
            <div class="flex flex-col gap-3 text-sm">
                <a href="<?php echo e(route('public.services', ['locale' => $activeLocale])); ?>" class="py-1.5 text-slate-200"><?php echo e(__('public.nav.services')); ?></a>
                <a href="<?php echo e(route('public.works', ['locale' => $activeLocale])); ?>" class="py-1.5 text-slate-200"><?php echo e(__('public.nav.works')); ?></a>
                <a href="<?php echo e(route('public.about', ['locale' => $activeLocale])); ?>" class="py-1.5 text-slate-200"><?php echo e(__('public.nav.about')); ?></a>
                <a href="<?php echo e(route('public.faq', ['locale' => $activeLocale])); ?>" class="py-1.5 text-slate-200"><?php echo e(__('public.nav.faq')); ?></a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($simple)): ?>
                <div class="flex flex-wrap items-center gap-2 pt-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['id' => 'ID', 'en' => 'EN']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <form method="POST" action="<?php echo e(route('locale.update', $code)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="min-h-10 rounded-md border border-slate-700 px-3 py-1.5 text-xs font-medium <?php echo e($activeLocale === $code ? 'bg-slate-700 text-white' : 'text-slate-300'); ?>">
                                <?php echo e($label); ?>

                            </button>
                        </form>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['IDR', 'USD']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <form method="POST" action="<?php echo e(route('public.currency', $curr)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="min-h-10 rounded-md border border-slate-700 px-3 py-1.5 text-xs font-medium <?php echo e($selectedCurrency->value === $curr ? 'bg-emerald-600 text-white' : 'text-slate-300'); ?>">
                                <?php echo e($curr); ?>

                            </button>
                        </form>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <a href="<?php echo e(route('public.start-project', ['locale' => $activeLocale])); ?>" class="mt-2 inline-flex min-h-11 items-center justify-center rounded-lg bg-emerald-600 px-4 py-2.5 font-semibold text-white">
                    <?php echo e(__('public.nav.start_project')); ?>

                </a>
            </div>
        </div>
    </header>

    <main>
        <?php echo e($slot); ?>

    </main>

    <footer class="border-t border-slate-800 bg-slate-950 text-slate-300">
        <div class="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
            <div>
                <div class="flex items-center gap-2.5 font-heading text-lg font-bold text-white">
                    <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-600 text-sm font-bold text-white">QC</span>
                    <span>Quix Code</span>
                </div>
                <p class="mt-3 text-sm leading-relaxed text-slate-400"><?php echo e(__('public.footer.tagline')); ?></p>
            </div>
            <div>
                <h2 class="font-heading text-sm font-semibold uppercase tracking-wider text-white"><?php echo e(__('public.footer.navigation')); ?></h2>
                <ul class="mt-3 space-y-2 text-sm">
                    <li><a href="<?php echo e(route('public.services', ['locale' => $activeLocale])); ?>" class="hover:text-white"><?php echo e(__('public.nav.services')); ?></a></li>
                    <li><a href="<?php echo e(route('public.works', ['locale' => $activeLocale])); ?>" class="hover:text-white"><?php echo e(__('public.nav.works')); ?></a></li>
                    <li><a href="<?php echo e(route('public.about', ['locale' => $activeLocale])); ?>" class="hover:text-white"><?php echo e(__('public.nav.about')); ?></a></li>
                    <li><a href="<?php echo e(route('public.faq', ['locale' => $activeLocale])); ?>" class="hover:text-white"><?php echo e(__('public.nav.faq')); ?></a></li>
                </ul>
            </div>
            <div>
                <h2 class="font-heading text-sm font-semibold uppercase tracking-wider text-white"><?php echo e(__('public.footer.legal')); ?></h2>
                <ul class="mt-3 space-y-2 text-sm">
                    <li><a href="<?php echo e(route('public.privacy', ['locale' => $activeLocale])); ?>" class="hover:text-white"><?php echo e(__('public.nav.privacy')); ?></a></li>
                    <li><a href="<?php echo e(route('public.terms', ['locale' => $activeLocale])); ?>" class="hover:text-white"><?php echo e(__('public.nav.terms')); ?></a></li>
                    <li><a href="<?php echo e(route('login')); ?>" class="hover:text-white"><?php echo e(__('public.nav.portal_login')); ?></a></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-slate-900 px-4 py-5 text-center text-xs text-slate-500">
            © <?php echo e(date('Y')); ?> Quix Code. <?php echo e(__('public.footer.rights')); ?>

        </div>
    </footer>
</body>
</html>
<?php /**PATH /home/qnf/Quix-Code/resources/views/layouts/public.blade.php ENDPATH**/ ?>