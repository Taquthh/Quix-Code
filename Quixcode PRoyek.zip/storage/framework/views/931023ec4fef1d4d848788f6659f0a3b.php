<?php # [BlazeVersion]:{v3} ?>
<?php
if (!function_exists('_8d3b48ed53c62bc4bb7fea969d2678ef')):
function _8d3b48ed53c62bc4bb7fea969d2678ef($__blaze, $__data = [], $__attributes = [], $__slots = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = new \Livewire\Blaze\Runtime\BlazeAttributeBag($__attributes);
unset($__data, $__attributes);
ob_start();
?>


<?php
$__defaults = [
    'length' => null,
    'private' => false,
];
$length ??= $attributes['length'] ?? $__defaults['length']; unset($attributes['length']);
$private ??= $attributes['private'] ?? $__defaults['private']; unset($attributes['private']);
unset($__defaults);
?>

<?php
    $classes = Flux::classes()
        ->add('flex items-center gap-2 isolate w-fit')
        ->add('[&_[data-flux-input-group]]:w-auto')
?>

<?php if (!function_exists('_01731118a2f05cd15cc446fc2abf17f6')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/with-field.blade.php'); } ?>
<?php if (isset($__slots01731118a2f05cd15cc446fc2abf17f6)) { $__slotsStack01731118a2f05cd15cc446fc2abf17f6[] = $__slots01731118a2f05cd15cc446fc2abf17f6; } ?>
<?php if (isset($__data01731118a2f05cd15cc446fc2abf17f6)) { $__dataStack01731118a2f05cd15cc446fc2abf17f6[] = $__data01731118a2f05cd15cc446fc2abf17f6; } ?>
<?php $__data01731118a2f05cd15cc446fc2abf17f6 = ['attributes' => $attributes]; ?>
<?php $__slots01731118a2f05cd15cc446fc2abf17f6 = []; ?>
<?php $__blaze->pushData($__data01731118a2f05cd15cc446fc2abf17f6); ?>
<?php ob_start(); ?>
    <ui-otp
        <?php echo e($attributes->class($classes)); ?>

        data-flux-otp
        data-flux-control
        role="group"
        data-flux-input-aria-label="<?php echo e(__('Character {current} of {total}')); ?>"
    >
        <?php if($slot->isEmpty() && $length): ?>
            <?php for($i = 0; $i < $length; $i++): ?>
                <?php if (!function_exists('_dfb8d857d7b2f7b06e8295b36d3ec53e')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/otp/input.blade.php'); } ?>
<?php $__componentData = []; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _dfb8d857d7b2f7b06e8295b36d3ec53e($__blaze, $__componentData, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php endfor; ?>
        <?php else: ?>
            <?php echo e($slot); ?>

        <?php endif; ?>
    </ui-otp>
<?php $__slots01731118a2f05cd15cc446fc2abf17f6['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots01731118a2f05cd15cc446fc2abf17f6); ?>
<?php _01731118a2f05cd15cc446fc2abf17f6($__blaze, $__data01731118a2f05cd15cc446fc2abf17f6, $__blaze->mergeAttributes(['attributes' => $__data01731118a2f05cd15cc446fc2abf17f6['attributes']]), $__slots01731118a2f05cd15cc446fc2abf17f6, $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack01731118a2f05cd15cc446fc2abf17f6)) { $__slots01731118a2f05cd15cc446fc2abf17f6 = array_pop($__slotsStack01731118a2f05cd15cc446fc2abf17f6); } ?>
<?php if (! empty($__dataStack01731118a2f05cd15cc446fc2abf17f6)) { $__data01731118a2f05cd15cc446fc2abf17f6 = array_pop($__dataStack01731118a2f05cd15cc446fc2abf17f6); } ?>
<?php $__blaze->popData(); ?><?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH /home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/otp/index.blade.php ENDPATH**/ ?>