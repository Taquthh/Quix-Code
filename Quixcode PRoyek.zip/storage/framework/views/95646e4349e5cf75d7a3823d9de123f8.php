<?php # [BlazeVersion]:{v3} ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['value' => 0, 'label' => null, 'size' => 'md', 'showValue' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['value' => 0, 'label' => null, 'size' => 'md', 'showValue' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $percent = max(0, min(100, (int) $value));
    $height = ['sm' => 'h-1.5', 'md' => 'h-2.5', 'lg' => 'h-4'][$size] ?? 'h-2.5';
    $name = $label ?? __('ui.progress');
?>

<div <?php echo e($attributes); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($label || $showValue): ?>
        <div class="mb-1.5 flex items-center justify-between gap-2 text-sm">
            <span class="font-medium text-slate-700 dark:text-slate-200"><?php echo e($label); ?></span>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showValue): ?>
                <span class="tabular-nums text-slate-600 dark:text-slate-300"><?php echo e($percent); ?>%</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div role="progressbar" aria-label="<?php echo e($name); ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo e($percent); ?>"
         class="w-full overflow-hidden rounded-full bg-slate-200/80 p-0.5 shadow-inner dark:bg-slate-800 <?php echo e($height); ?>">
        <div class="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 shadow-[0_0_10px_rgb(16_185_129_/_0.25)] transition-[width] duration-500" style="width: <?php echo e($percent); ?>%"></div>
    </div>
</div>
<?php /**PATH /home/qnf/Quix-Code/resources/views/components/progress-bar.blade.php ENDPATH**/ ?>