<?php # [BlazeVersion]:{v3} ?>
<?php # [BlazeFolded]:{flux::button}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/button/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::select.option}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/select/option/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::select.option}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/select/option/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::select.option}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/select/option/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::button}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/button/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::button}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/button/index.blade.php}:{1795048155} ?>
<?php # [BlazeFolded]:{flux::button}:{/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/button/index.blade.php}:{1795048155} ?>
<div class="flex flex-col gap-6">
    <div class="flex flex-wrap items-start justify-between gap-3">
        <div>
            <h1 class="font-heading text-2xl font-bold text-slate-900 dark:text-slate-50"><?php echo e(__('admin.templates.title')); ?></h1>
            <p class="text-sm text-slate-600 dark:text-slate-400"><?php echo e(__('admin.templates.subtitle')); ?></p>
        </div>
        <?php ob_start(); ?><a href="<?php echo e(route('admin.settings')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-white hover:bg-zinc-50 dark:bg-zinc-700 dark:hover:bg-zinc-600/75 text-zinc-800 dark:text-white border border-zinc-200 hover:border-zinc-200 disabled:border-zinc-200 border-b-zinc-300/80 dark:border-zinc-600 dark:hover:border-zinc-600 dark:disabled:border-zinc-600 shadow-xs [[data-flux-button-group]_&amp;]:border-s-0 [:is([data-flux-button-group]&gt;&amp;:first-child,_[data-flux-button-group]_:first-child&gt;&amp;)]:border-s-[1px]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <?php ob_start(); ?><?php echo e(__('admin.templates.back')); ?><?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.templates.choose')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.templates.choose'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <div class="grid gap-4 md:grid-cols-3">
            <?php if (!function_exists('_23cea1bbbb062f7ad67da68988ba5564')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/select/index.blade.php'); } ?>
<?php if (isset($__slots23cea1bbbb062f7ad67da68988ba5564)) { $__slotsStack23cea1bbbb062f7ad67da68988ba5564[] = $__slots23cea1bbbb062f7ad67da68988ba5564; } ?>
<?php if (isset($__data23cea1bbbb062f7ad67da68988ba5564)) { $__dataStack23cea1bbbb062f7ad67da68988ba5564[] = $__data23cea1bbbb062f7ad67da68988ba5564; } ?>
<?php $__data23cea1bbbb062f7ad67da68988ba5564 = ['wire:model.live' => 'templateKey','label' => __('admin.templates.key')]; ?>
<?php $__slots23cea1bbbb062f7ad67da68988ba5564 = []; ?>
<?php $__blaze->pushData($__data23cea1bbbb062f7ad67da68988ba5564); ?>
<?php ob_start(); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php ob_start(); ?><option
    
     value="<?php echo e($key); ?>"      <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = ''.e($key).''; ?>wire:key="<?php echo e($key); ?>" ><?php ob_start(); ?><?php echo e(__('admin.templates.keys.'.$key)); ?><?php echo trim(ob_get_clean()); ?></option><?php echo ltrim(ob_get_clean()); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php $__slots23cea1bbbb062f7ad67da68988ba5564['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots23cea1bbbb062f7ad67da68988ba5564); ?>
<?php _23cea1bbbb062f7ad67da68988ba5564($__blaze, $__data23cea1bbbb062f7ad67da68988ba5564, ['wire:model.live' => 'templateKey', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__data23cea1bbbb062f7ad67da68988ba5564['label'])], $__slots23cea1bbbb062f7ad67da68988ba5564, $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack23cea1bbbb062f7ad67da68988ba5564)) { $__slots23cea1bbbb062f7ad67da68988ba5564 = array_pop($__slotsStack23cea1bbbb062f7ad67da68988ba5564); } ?>
<?php if (! empty($__dataStack23cea1bbbb062f7ad67da68988ba5564)) { $__data23cea1bbbb062f7ad67da68988ba5564 = array_pop($__dataStack23cea1bbbb062f7ad67da68988ba5564); } ?>
<?php $__blaze->popData(); ?>
            <?php if (!function_exists('_23cea1bbbb062f7ad67da68988ba5564')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/select/index.blade.php'); } ?>
<?php if (isset($__slots23cea1bbbb062f7ad67da68988ba5564)) { $__slotsStack23cea1bbbb062f7ad67da68988ba5564[] = $__slots23cea1bbbb062f7ad67da68988ba5564; } ?>
<?php if (isset($__data23cea1bbbb062f7ad67da68988ba5564)) { $__dataStack23cea1bbbb062f7ad67da68988ba5564[] = $__data23cea1bbbb062f7ad67da68988ba5564; } ?>
<?php $__data23cea1bbbb062f7ad67da68988ba5564 = ['wire:model.live' => 'templateLocale','label' => __('admin.templates.locale')]; ?>
<?php $__slots23cea1bbbb062f7ad67da68988ba5564 = []; ?>
<?php $__blaze->pushData($__data23cea1bbbb062f7ad67da68988ba5564); ?>
<?php ob_start(); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php ob_start(); ?><option
    
     value="<?php echo e($code); ?>"      <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = ''.e($code).''; ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = ''.e($code).''; ?>wire:key="<?php echo e($code); ?>" ><?php ob_start(); ?><?php echo e(__('admin.templates.locales.'.$code)); ?><?php echo trim(ob_get_clean()); ?></option><?php echo ltrim(ob_get_clean()); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php $__slots23cea1bbbb062f7ad67da68988ba5564['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots23cea1bbbb062f7ad67da68988ba5564); ?>
<?php _23cea1bbbb062f7ad67da68988ba5564($__blaze, $__data23cea1bbbb062f7ad67da68988ba5564, ['wire:model.live' => 'templateLocale', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__data23cea1bbbb062f7ad67da68988ba5564['label'])], $__slots23cea1bbbb062f7ad67da68988ba5564, $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack23cea1bbbb062f7ad67da68988ba5564)) { $__slots23cea1bbbb062f7ad67da68988ba5564 = array_pop($__slotsStack23cea1bbbb062f7ad67da68988ba5564); } ?>
<?php if (! empty($__dataStack23cea1bbbb062f7ad67da68988ba5564)) { $__data23cea1bbbb062f7ad67da68988ba5564 = array_pop($__dataStack23cea1bbbb062f7ad67da68988ba5564); } ?>
<?php $__blaze->popData(); ?>
            <?php if (!function_exists('_23cea1bbbb062f7ad67da68988ba5564')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/select/index.blade.php'); } ?>
<?php if (isset($__slots23cea1bbbb062f7ad67da68988ba5564)) { $__slotsStack23cea1bbbb062f7ad67da68988ba5564[] = $__slots23cea1bbbb062f7ad67da68988ba5564; } ?>
<?php if (isset($__data23cea1bbbb062f7ad67da68988ba5564)) { $__dataStack23cea1bbbb062f7ad67da68988ba5564[] = $__data23cea1bbbb062f7ad67da68988ba5564; } ?>
<?php $__data23cea1bbbb062f7ad67da68988ba5564 = ['wire:model.live' => 'templateChannel','label' => __('admin.templates.channel')]; ?>
<?php $__slots23cea1bbbb062f7ad67da68988ba5564 = []; ?>
<?php $__blaze->pushData($__data23cea1bbbb062f7ad67da68988ba5564); ?>
<?php ob_start(); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php ob_start(); ?><option
    
     value="<?php echo e($code); ?>"      <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = ''.e($code).''; ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = ''.e($code).''; ?>wire:key="<?php echo e($code); ?>" ><?php ob_start(); ?><?php echo e(__('admin.templates.channels.'.$code)); ?><?php echo trim(ob_get_clean()); ?></option><?php echo ltrim(ob_get_clean()); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php $__slots23cea1bbbb062f7ad67da68988ba5564['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots23cea1bbbb062f7ad67da68988ba5564); ?>
<?php _23cea1bbbb062f7ad67da68988ba5564($__blaze, $__data23cea1bbbb062f7ad67da68988ba5564, ['wire:model.live' => 'templateChannel', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__data23cea1bbbb062f7ad67da68988ba5564['label'])], $__slots23cea1bbbb062f7ad67da68988ba5564, $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack23cea1bbbb062f7ad67da68988ba5564)) { $__slots23cea1bbbb062f7ad67da68988ba5564 = array_pop($__slotsStack23cea1bbbb062f7ad67da68988ba5564); } ?>
<?php if (! empty($__dataStack23cea1bbbb062f7ad67da68988ba5564)) { $__data23cea1bbbb062f7ad67da68988ba5564 = array_pop($__dataStack23cea1bbbb062f7ad67da68988ba5564); } ?>
<?php $__blaze->popData(); ?>
        </div>
        <?php if (!function_exists('_da6feeb405af189fc0eced19dbef8790')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/error.blade.php'); } ?>
<?php $__componentData = ['name' => 'templateKey']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _da6feeb405af189fc0eced19dbef8790($__blaze, $__componentData, ['name' => 'templateKey'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

    <div class="grid gap-6 xl:grid-cols-2">
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.templates.editor')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.templates.editor'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <form wire:submit="save" class="flex flex-col gap-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($templateChannel === 'email'): ?>
                    <?php if (!function_exists('_1bed5b009773c7235471572d8b2301e7')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/input/index.blade.php'); } ?>
<?php $__componentData = ['wire:model.live.debounce.300ms' => 'subject','label' => __('admin.templates.subject'),'maxlength' => '190']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _1bed5b009773c7235471572d8b2301e7($__blaze, $__componentData, ['wire:model.live.debounce.300ms' => 'subject', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'maxlength' => '190'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('_da6feeb405af189fc0eced19dbef8790')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/error.blade.php'); } ?>
<?php $__componentData = ['name' => 'subject']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _da6feeb405af189fc0eced19dbef8790($__blaze, $__componentData, ['name' => 'subject'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if (!function_exists('_a1b156ddfea0f8b6864e9c3dbd3bc029')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/textarea.blade.php'); } ?>
<?php $__componentData = ['wire:model.live.debounce.300ms' => 'body','label' => __('admin.templates.body'),'rows' => '12']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _a1b156ddfea0f8b6864e9c3dbd3bc029($__blaze, $__componentData, ['wire:model.live.debounce.300ms' => 'body', 'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($__componentData['label']), 'rows' => '12'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php if (!function_exists('_da6feeb405af189fc0eced19dbef8790')) { require $__blaze->compile('/home/qnf/Quix-Code/vendor/livewire/flux/stubs/resources/views/flux/error.blade.php'); } ?>
<?php $__componentData = ['name' => 'body']; ?>
<?php $__blaze->pushData($__componentData); ?>
<?php _da6feeb405af189fc0eced19dbef8790($__blaze, $__componentData, ['name' => 'body'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>

                <p class="text-xs text-slate-600 dark:text-slate-400">
                    <?php echo e($templateChannel === 'email' ? __('admin.templates.email_hint') : __('admin.templates.whatsapp_hint')); ?>

                </p>

                <div>
                    <p class="mb-2 text-xs font-medium uppercase text-slate-600 dark:text-slate-400"><?php echo e(__('admin.templates.variables')); ?></p>
                    <ul class="flex flex-col gap-1 text-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->variables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <li <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'var-'.e($variable).''; ?>wire:key="var-<?php echo e($variable); ?>">
                                <code class="rounded bg-slate-100 px-1.5 py-0.5 text-xs text-slate-800 dark:bg-slate-800 dark:text-slate-200"><?php echo e($this->token($variable)); ?></code>
                                <span class="text-slate-600 dark:text-slate-400"><?php echo e(__('admin.templates.variable_labels.'.$variable)); ?></span>
                            </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </ul>
                </div>

                <div class="flex flex-wrap gap-2">
                    <?php ob_start(); ?><button type="submit" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[1px]! [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)] *:transition-opacity [&amp;[disabled]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[disabled]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[disabled]]:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?><?php echo e(__('admin.templates.save')); ?><?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-white hover:bg-zinc-50 dark:bg-zinc-700 dark:hover:bg-zinc-600/75 text-zinc-800 dark:text-white border border-zinc-200 hover:border-zinc-200 disabled:border-zinc-200 border-b-zinc-300/80 dark:border-zinc-600 dark:hover:border-zinc-600 dark:disabled:border-zinc-600 shadow-xs [[data-flux-button-group]_&amp;]:border-s-0 [:is([data-flux-button-group]&gt;&amp;:first-child,_[data-flux-button-group]_:first-child&gt;&amp;)]:border-s-[1px] *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:target="useDefault" wire:loading.attr="data-flux-loading" wire:click="useDefault">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?><?php echo e(__('admin.templates.use_default')); ?><?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

        <div class="flex flex-col gap-6">
            <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.templates.preview')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.templates.preview'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                <div class="flex flex-col gap-3 text-sm text-slate-900 dark:text-slate-50" data-testid="template-preview">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($templateChannel === 'email'): ?>
                        <p class="font-semibold"><?php echo e($this->preview->subject); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->preview->paragraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <p class="whitespace-pre-line"><?php echo e($paragraph); ?></p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <p class="text-slate-600 dark:text-slate-400"><?php echo e(__('admin.templates.preview_empty')); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <p class="mt-3 text-xs text-slate-600 dark:text-slate-400"><?php echo e(__('admin.templates.preview_hint')); ?></p>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => __('admin.templates.history')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('admin.templates.history'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->versions->isEmpty()): ?>
                    <p class="text-sm text-slate-600 dark:text-slate-400"><?php echo e(__('admin.templates.no_versions')); ?></p>
                <?php else: ?>
                    <ul class="divide-y divide-slate-200 text-sm dark:divide-slate-800">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <li <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'version-'.e($version->id).''; ?>wire:key="version-<?php echo e($version->id); ?>" class="flex items-center justify-between gap-3 py-2">
                                <span>
                                    <span class="font-medium text-slate-900 dark:text-slate-50">v<?php echo e($version->version); ?></span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loop->first): ?>
                                        <span class="ml-1 rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300"><?php echo e(__('admin.templates.active')); ?></span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <span class="block text-xs text-slate-600 dark:text-slate-400"><?php echo e($version->created_at?->translatedFormat('j F Y H:i')); ?></span>
                                </span>
                                <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-8 text-sm rounded-md gap-2 ps-3 pe-3 inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 in-data-flux-sidebar:data-open:bg-zinc-800/5 dark:in-data-flux-sidebar:data-open:bg-white/15 text-zinc-800 dark:text-white    *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" wire:target="restore(<?php echo e($version->version); ?>)" wire:loading.attr="data-flux-loading" wire:click="restore(<?php echo e($version->version); ?>)">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?><?php echo e(__('admin.templates.load')); ?><?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                            </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </ul>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/qnf/Quix-Code/resources/views/livewire/admin/settings/notification-templates.blade.php ENDPATH**/ ?>