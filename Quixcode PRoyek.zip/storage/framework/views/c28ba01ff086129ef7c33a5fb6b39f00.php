<?php # [BlazeVersion]:{v3} ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status', 'label' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status', 'label' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $value = $status instanceof \BackedEnum ? (string) $status->value : (string) $status;

    $tone = match ($value) {
        'active', 'paid', 'resolved', 'accepted', 'done', 'verified' => 'success',
        'awaiting_dp', 'awaiting_final', 'awaiting_verification', 'unpaid', 'negotiating', 'open' => 'warning',
        'quoted', 'deal', 'sent', 'in_progress', 'handover', 'warranty' => 'info',
        'cancelled', 'rejected', 'failed', 'expired' => 'danger',
        default => 'neutral', // lead, draft, pending, closed, dll.
    };

    $classes = [
        'neutral' => 'bg-slate-100 text-slate-700 ring-slate-300 dark:bg-slate-800 dark:text-slate-200 dark:ring-slate-600',
        'info' => 'bg-sky-50 text-sky-800 ring-sky-200 dark:bg-sky-500/15 dark:text-sky-300 dark:ring-sky-500/30',
        'warning' => 'bg-amber-50 text-amber-800 ring-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
        'success' => 'bg-emerald-50 text-emerald-800 ring-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
        'danger' => 'bg-rose-50 text-rose-800 ring-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:ring-rose-500/30',
    ][$tone];

    $dotClasses = [
        'neutral' => 'bg-slate-400 dark:bg-slate-400',
        'info' => 'bg-sky-500 dark:bg-sky-400',
        'warning' => 'bg-amber-500 dark:bg-amber-400',
        'success' => 'bg-emerald-500 dark:bg-emerald-400',
        'danger' => 'bg-rose-500 dark:bg-rose-400',
    ][$tone];

    $text = $label
        ?? (($status instanceof \BackedEnum && method_exists($status, 'label')) ? $status->label() : \Illuminate\Support\Str::headline($value));
?>

<span <?php echo e($attributes->class(['inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset', $classes])); ?>>
    <span aria-hidden="true" class="me-1.5 size-1.5 shrink-0 rounded-full <?php echo e($dotClasses); ?>"></span>
    <?php echo e($text); ?>

</span>
<?php /**PATH /home/qnf/Quix-Code/resources/views/components/badge-status.blade.php ENDPATH**/ ?>