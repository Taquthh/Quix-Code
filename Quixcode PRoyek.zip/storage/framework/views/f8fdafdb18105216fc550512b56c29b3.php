<?php # [BlazeVersion]:{v3} ?>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>
    <?php echo e(filled($title ?? null) ? __($title).' - '.config('app.name', 'Laravel') : config('app.name', 'Laravel')); ?>

</title>

<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

<script>
    try {
        if (! localStorage.getItem('flux.appearance')) {
            localStorage.setItem('flux.appearance', <?php echo \Illuminate\Support\Js::from($appearance ?? 'dark')->toHtml() ?>);
        }
    } catch (e) {}
</script>
<?php echo app('flux')->fluxAppearance(); ?>

<?php /**PATH /home/qnf/Quix-Code/resources/views/partials/head.blade.php ENDPATH**/ ?>